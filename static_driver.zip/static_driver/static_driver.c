#include<linux/module.h>
#include<linux/init.h>
#include<linux/kernel.h>
#include<linux/fs.h>

dev_t my_dev = MKDEV(300, 0);

static int __init static_driver_init(void)
{
	register_chrdev_region(my_dev, 1, "char_dev");
	printk(KERN_INFO "Driver registered successfully\n");
	printk(KERN_INFO "Major no. = %d, Minor no. = %d\n", MAJOR(my_dev), MINOR(my_dev));

	return 0;
}

static void __exit static_driver_exit(void)
{
	unregister_chrdev_region(my_dev, 1);
	printk(KERN_INFO "Driver unregistered successfully\n");
}

module_init(static_driver_init);
module_exit(static_driver_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rakshitha S");
MODULE_DESCRIPTION("Static driver");
