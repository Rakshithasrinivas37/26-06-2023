#include<linux/module.h>
#include<linux/init.h>
#include<linux/kernel.h>
#include<linux/fs.h>
#include<linux/kdev_t.h>
#include<linux/device.h>

dev_t my_dev;
static struct class *dev_class;

static int __init static_driver_init(void)
{
        alloc_chrdev_region(&my_dev, 0, 1, "char_dev");
        printk(KERN_INFO "Driver registered successfully\n");
        printk(KERN_INFO "Major no. = %d, Minor no. = %d\n", MAJOR(my_dev), MINOR(my_dev));

	dev_class = class_create(THIS_MODULE, "my_class");

	device_create(dev_class, NULL, my_dev, NULL, "my_device");

        return 0;
}

static void __exit static_driver_exit(void)
{
	device_destroy(dev_class, my_dev);
	class_destroy(dev_class);
        unregister_chrdev_region(my_dev, 1);
        printk(KERN_INFO "Driver unregistered successfully\n");
}

module_init(static_driver_init);
module_exit(static_driver_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rakshitha S");
MODULE_DESCRIPTION("Static driver");
